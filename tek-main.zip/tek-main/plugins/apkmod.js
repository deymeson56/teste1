//jangan ubah om plisss
//om jangan ambil
//yah om
let handler = async m => m.reply(`
〘 APK LIST 𝗠𝗢𝗗 〙
❃❃❃❃❃❃❃❃❃❃❃❃❃❃❃
      Tekashi:) *01* 
❃❃❃❃❃❃❃❃❃❃❃❃❃❃❃
%readmore
➨𝗔𝗹𝗶𝗴𝗵𝘁 𝗠𝗼𝘁𝗶𝗼𝗻 𝗺𝗼𝗱
➢https://apkdone.com/alight-motion/'
%readmore
➨𝗞𝗶𝗻𝗲𝗺𝗮𝘀𝘁𝗲𝗿
➢https://apkdone.com/kinemaster-apk-mods/
%readmore
➨𝗜𝗻𝘀𝗵𝗼𝘁
➢https://apkdone.com/inshot/
%readmore
➨𝗙𝗶𝗹𝗺𝗼𝗿𝗮𝗚𝗼
➢https://apkdone.com/filmorago/
%readmore
➨𝗟𝗶𝗴𝗵𝘁𝗿𝗼𝗼𝗺
➢https://apkdone.com/adobe-lightroom/
%readmore
➨𝗣𝗶𝗰𝘀𝗮𝗿𝘁
➢https://apkdone.com/picsart-apk-mods/
`.trim()) 
handler.help = ['apkmod']
handler.tags = ['tools']
handler.command = /^apkmod|aplikasimod$/i

module.exports = handler
